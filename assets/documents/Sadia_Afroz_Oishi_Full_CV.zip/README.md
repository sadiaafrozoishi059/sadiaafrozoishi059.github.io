# Sadia Afroz Oishi - Academic CV (Ariful Islam CV Design)

This folder contains the complete LaTeX source and assets for **Sadia Afroz Oishi's CV**, styled to match the exact design, typography, geometry, and layout of **Ariful Islam's CV**.

---

## Files Included

- **`cv.tex`**: The primary LaTeX document. Contains all academic profile details, research experiences, publications, talks, skills, leadership, and references.
- **`Sadia-Afroz-Oishi-Photograph.jpg`**: High-resolution formal portrait photograph optimized for LaTeX.
- **`formal_pic.png`**: The original source portrait photograph.

---

## Overleaf Compilation Instructions

1. **Option A (Direct Zip Upload - Recommended)**:
   - In Overleaf, click **New Project** $\rightarrow$ **Upload Project**.
   - Upload the provided `Sadia_Afroz_Oishi_CV_Overleaf_Ready.zip` file.
   - Click **Recompile** (the default `pdfLaTeX` compiler works directly; `XeLaTeX` also works seamlessly).

2. **Option B (Manual Files Upload)**:
   - Create a blank project in Overleaf.
   - Upload `cv.tex` and `Sadia-Afroz-Oishi-Photograph.jpg`.
   - Click **Recompile**.

---

## Design Specifications Matching Ariful's CV

- **Page Geometry & Margins**: A4 paper scale ($0.9$ geometry) with balanced spacing.
- **Header Layout**:
  - Two-column header with candidate name in `\Huge`, department and institutional affiliation.
  - Interactive icons (`fontawesome5`) for Email, Phone, LinkedIn, and Google Scholar.
  - Right-aligned framed formal portrait photograph (`width=3.6cm`).
- **Section Styling**: Small-caps headings (`\Large\scshape\raggedright`) paired with clean horizontal divider rules (`\titlerule`).
- **Structured Sections**:
  - **Overview**: Concise research trajectory narrative.
  - **Education**: Two-column tabular alignment (`tabularx`).
  - **Academic Service & Certifications**: Bulleted conference peer-review records.
  - **Publications**: Grouped by Submitted Journal Manuscripts, Published Datasets, and Peer-Reviewed Conference Papers with clickable DOI links.
  - **Selected Research Experience**: Compact project blocks (`jobshort`) with bulleted technical contributions.
  - **Research Interests**: Semicolon-delimited core domain areas.
  - **Skills & Coursework**: Tabular categorization of AI/Research, Programming, Tools, and Coursework.
  - **Achievements**: Major accolades and academic performance.
  - **Talks & Presentations**: Formatted presentations table with dates and venues.
  - **Volunteering & Leadership**: Club leadership and media/podcast hosting roles.
  - **Languages**: Native and professional proficiencies.
  - **References**: Stacked academic referee blocks for Dr. Md. Sarwar Hossain and Dr. Md. Anwar Hossain.
